using System;

namespace PassGen
{
	[Gtk.TreeNode (ListOnly=true)]
	public class GenTreeNode : Gtk.TreeNode {

		string song_title;
		string TYPE;


		public GenTreeNode (string artist, string song_title,string type)
		{
			Artist = artist;
			this.song_title = song_title;
			this.TYPE = type;
		}

		[Gtk.TreeNodeValue (Column=0)]
		public string Artist;

		[Gtk.TreeNodeValue (Column=1)]
		public string SongTitle {get{return song_title;}}

		[Gtk.TreeNodeValue (Column=2)]
		public string Type {get { return TYPE; } }
	}
}

